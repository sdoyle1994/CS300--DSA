/*Shane Doyle
2/16/23
CS300 Final Project*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include<algorithm>
#include <sstream>

using namespace std;


//course struct
struct Course {
	string courseNumber;
	string courseTitle;
	vector<string>prerequisites{ "",""};

};
//loadCourses function
vector<Course> loadCourses(string csvPath) {

	vector<Course> courses;
	//create ifstream object
	ifstream inputFile;
	//open file
	inputFile.open(csvPath);

	vector<string>row;

	string line;
	string word;


	//if file opens
	if (inputFile) {
		//loop until eof
		while (inputFile.peek() != EOF) {
			Course course;
			row.clear();

			getline(inputFile, line);
			stringstream s(line);


			while (getline(s, word, ',')) {
				row.push_back(word);
				
			}
			//if less than 2 values
			if (row.size() < 2) {
				cout << "File Format Error." << endl;
				exit(-1);
			}
			//if 2 values exist on a line
			else if (row.size() == 2 ) {
				course.courseNumber = row.at(0);
				course.courseTitle = row.at(1);
				
			}
			//if 3 values exist on a line
			else if (row.size() == 3){
				course.courseNumber = row.at(0);
				course.courseTitle = row.at(1);
				course.prerequisites.at(0) = row.at(2);
			}

			else {
				course.courseNumber = row.at(0);
				course.courseTitle = row.at(1);
				course.prerequisites.at(0) = row.at(2);
				course.prerequisites.at(1) = row.at(3);
			}
			//push course object onto vector
			courses.push_back(course);

		}

		//close file
		inputFile.close();
		
	}
	//return courses vector
	return courses;
}
//displayCourse function
void displayCourse(Course course) {
	cout << course.courseNumber << ", " << course.courseTitle << endl;
	
}
//displayParticularCourse function
void displayParticularCourse(Course course) {
	cout << course.courseNumber << ", " << course.courseTitle << endl;
	
	
	//0 prerequisites
	if (course.prerequisites.at(0) == "") {
		cout << "Prerequisites: None" << endl << endl;
	}
	//1 prerequisite
	else if (course.prerequisites.at(0) != "" && course.prerequisites.at(1) == "") {
		cout << "Prerequisites: " << course.prerequisites.at(0) << endl << endl;
	}

	//2 prerequisites
	else {
		cout << "Prerequisites: " << course.prerequisites.at(0) << ", " << course.prerequisites.at(1) << endl << endl;
	}
	
	

}

//partition function
int partition(vector<Course>& courses, int begin, int end) {
	//set low and high equal to begin and end
	int low = begin;
	int high = end;
	int midpoint;

	// pick the middle element as pivot point
	midpoint = begin + (end - begin) / 2;
	string pivot;
	pivot = courses.at(midpoint).courseNumber;

	//set flag
	bool done = false;

	// while not done 
	while (!done) {

		// keep incrementing low index while bids[low] < bids[pivot]
		while (courses.at(low).courseNumber < pivot) {
			low += 1;
		}

		// keep decrementing high index while bids[pivot] < bids[high]
		while (pivot < courses.at(high).courseNumber) {
			high -= 1;
		}

		/* If there are zero or one elements remaining,
		 all bids are partitioned. Return high */
		if (low >= high) {
			done = true;
		}
		// else swap the low and high bids (built in vector method)
		else {
			swap(courses.at(low), courses.at(high));

			// move low and high closer ++low, --high
			++low;
			--high;
		}
	}
	//return high;
	return high;
}
//quicksort function
void quickSort(vector<Course>& courses, int begin, int end) {
	//set mid equal to 0
	int mid = 0;

	/* Base case: If there are 1 or zero bids to sort,
	 partition is already sorted otherwise if begin is greater
	 than or equal to end then return*/
	if (begin >= end) {
		return;
	}

	/* Partition bids into low and high such that
	 midpoint is location of last element in low */
	mid = partition(courses, begin, end);

	// recursively sort low partition (begin to mid)
	quickSort(courses, begin, mid);

	// recursively sort high partition (mid+1 to end)
	quickSort(courses, mid + 1, end);

	return;
}


int main() {

	//define a vector to hold all courses
	vector<Course> courses;
	//define a string to hold csv file name
	string csvPath = "abcu.csv";

	//display menu
	int choice = 0;
	while (choice != 9) {
		cout << "Welcome to the course planner.\n\n";
		cout << "   1. Load Data Structure." << endl;
		cout << "   2. Print Course List." << endl;
		cout << "   3. Print Course." << endl;
		cout << "   9. Exit." << endl;
		cout << "\nWhat would you like to do? ";
		cin >> choice;
		cout << "\n";

		switch (choice) {
		case 1:
			courses = loadCourses(csvPath);
			break;
		case 2:
			//call quicksort to sort courses in alphanumeric order
			quickSort(courses, 0, courses.size() - 1);
			
			unsigned int i;
			//display courses
			cout << "Here is a sample schedule: \n\n";
			for (i = 0; i < courses.size(); i++) {
				displayCourse(courses.at(i));
			}
			cout << endl;
			break;
		case 3: {
			unsigned int i;
			string courseName;
			bool foundCourse = false;
			cout << "What course do you want to know about? ";
			cin >> courseName;
			
			//convert to uppercase
			for (i = 0; i < courseName.length(); i++) {
				courseName[i] = toupper(courseName[i]);
			}
			//iterate through vector to find a match
			for (i = 0; i < courses.size(); i++) {
				//if found
				if (courseName == courses.at(i).courseNumber) {
					displayParticularCourse(courses.at(i));
					//found course equals true
					foundCourse = true;
				}

			}
			//if not found
			if (!foundCourse) {
				cout << "\nCourse doesn't exist.\n\n";
			}

			break;
		}
		case 9:
			//exit program
			cout << "Thank you for using the course planner!" << endl;
			
			break;
		default:
			cout << choice << " is not a valid option.\n\n";
			break;
		}
	}
	system("pause");
	return 0;
}